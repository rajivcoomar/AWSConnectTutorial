
var axios = require('axios');

exports.handler  = async function(event, context) {
    // TODO implement
 let config = {
  method: 'get',
  maxBodyLength: Infinity,
  url: 'http://api.weatherapi.com/v1/current.json?key=<key>&q=pune',
  headers: { }
};

axios.request(config)
.then((response) => {
  console.log(JSON.stringify(response.data));
})
.catch((error) => {
  console.log(error);
});
};
