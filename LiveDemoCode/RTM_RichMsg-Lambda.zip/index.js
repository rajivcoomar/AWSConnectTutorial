  
  /* MAIN HANDLER */
  exports.handler  = async function(event, context) {
    try {
      console.log(`Request received: ${JSON.stringify(event)}`);
      let response = handleRequest(event);
      console.log(`Returning response: ${JSON.stringify(response)}`);
      return response;
    } catch (err) {
      console.error(`Error processing Lex request:`, err);
      var sessionAttributes = event.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState : "FAILED",
          message: {
            contentType: "PlainText",
            content: "Error in Lex Lambda",
          },
        },
      };
     }
  };
  
  /* PROCESS INBOUND MESSAGE */
  function handleRequest(request) {
  
    let current_intent = request.currentIntent.name;

    let jsonList = {
      "templateType":"ListPicker",                       
      "version":"1.0",                                   
      "data":{                                           
     
         "content":{                                        
            "title":"How may I assist you?", 
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://www.goindigo.in/content/dam/indigov2/6e-website/downloadapp/Feature-Image.png",                  
            "imageDescription":"Select any of the option",
            "elements":[                                   
               {
                  "title":"Book a Flight",                      
                 
                  "imageType":"URL",
                  "imageData":"https://cdn0.iconfinder.com/data/icons/travel-line-color-this-is-vacation-time/512/Flight_booking-512.png"
               },
               {
                  "title":"Flight Information",                         
                
                  "imageType":"URL",                  
                  "imageData":"https://static.thenounproject.com/png/3652216-200.png",           
               },
                {
                  "title":"Manage Booking",                         
                
                  "imageType":"URL",                  
                  "imageData":"https://cdn0.iconfinder.com/data/icons/miscellaneous-22-line/128/booking_travel_tourism_online_reservation_ticket_air-ticket-512.png",            
                  "imageDescription":"Banana"
               }
               ,
               {
                "title":"Contact Us",                         
             
                "imageType":"URL",                  
                "imageData":"https://cdn-icons-png.flaticon.com/512/3095/3095583.png",            
                "imageDescription":"Banana"
             }
            ]
         }
     }
   };
   
   

   let jsonTimePicker = {
    "templateType":"TimePicker",                                 
    "version":"1.0",                                             
    "data":{                                                     
       "replyMessage":{
          "title":"Thanks for selecting",                        
          "subtitle":"Appointment selected",
       },
       "content":{                                               
          "title":"Schedule appointment",                        
          "subtitle":"Tap to select option",
          "timeZoneOffset":-450,
          "location":{
             "latitude":47.616299,                               
             "longitude":-122.4311,                              
             "title":"Oscar" ,                                    
             "radius":1,
          },
          "timeslots":[                                          
                {
                   "date" : "2020-10-31T17:00+00:00" ,            
                   "duration": 60,                               
                },
                {
                   "date" : "2020-11-15T13:00+00:00" ,           
                   "duration": 60,                              
                },
                {
                   "date" : "2020-11-15T16:00+00:00" ,           
                   "duration": 60,                              
                }
             ],           
          }
       }
    };

    let jsonPanel = {
      "templateType":"Panel",                            
      "version":"1.0",                                   
      "data":{                                           
         "replyMessage":{                             
            "title":"Thanks for selecting!",             
            "subtitle":"Option selected",
         },
         "content":{                                      
            "title":"How can I help you?",                
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://interactive-msg.s3-us-west-2.amazonaws.com/company.jpg",                  
            "imageDescription":"Select an option",
            "elements":[                                  
               {
                  "title":"Check self-service options",   
               },
               {
                  "title":"Talk to an agent",                      
               },
               {
                  "title":"End chat",                     
               }
            ]
         }
      }
   } ;



  let jsonCarousel ={
    "templateType": "Carousel",            
    "version": "1.0",                      
    "data": {                              
        "content": {                           
          "title": "View our popular destinations",   
          "elements": [                               
          {
            "templateIdentifier": "template0",        
            "templateType": "Panel",
            "version": "1.0",
            "data": {
              "content": {
                "title": "Saver",
                "subtitle": "Tap to select option",
                "elements": [
                  {
                    "title": "Book flights"  //Training phrase in intent - templateIdentifier template listTitle California selectionText Book flights
                  },
                  {
                    "title": "Learn More",
                     "type": "hyperlink",
                    "url": "https://www.goindigo.in/?linkNav=Logo%7C%7CHeader"
                  }
                ]
              }
            }
          },
          {
            "templateIdentifier": "template1",   
            "templateType": "Panel",
            "version": "1.0",
            "data": {
              "content": {
                "title": "Flexi plus",
                "subtitle": "Tap to select option",
                "elements": [
                  {
                    "title": "Book flights"   //Training phrase in intent - templateIdentifier template listTitle New York selectionText Book flights
                  },
                   {
                    "title": "Learn More",
                     "type": "hyperlink",
                    "url": "https://www.goindigo.in/?linkNav=Logo%7C%7CHeader"
                  }
                ]
              }
            }
          },
          {
            "templateIdentifier": "template2",   
            "templateType": "Panel",
            "version": "1.0",
            "data": {
              "content": {
                "title": "Super 6E",
                "subtitle": "Tap to select option",
                "elements": [
                  {
                    "title": "Book flights"   //Training phrase in intent - templateIdentifier template listTitle New York selectionText Book flights
                  },
                   {
                    "title": "Learn More",
                     "type": "hyperlink",
                    "url": "https://www.goindigo.in/?linkNav=Logo%7C%7CHeader"
                  }
                ]
              }
            }
          }
        ]
      }
    }
  };



   if(current_intent === 'Help')
    {
      var sessionAttributes = request.sessionAttributes;
     
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonList),
          },
        },
      };
    }

    else if(current_intent === 'AskNumber')
    {
      
        var fCity = request.sessionAttributes.FromCity;
         var tCity =request.sessionAttributes.ToCity;
       var DepDate =request.sessionAttributes.DepDate;
        var number =request.currentIntent.slots.Number;
      var sessionAttributes = request.sessionAttributes;
      sessionAttributes.NoOfPassenger = number;
    
       let jsonQuick = {
        "templateType": "QuickReply",        
        "version": "1.0",                    
        "data": {                            
          "content": {                       
            "title": "Thank you for sharing the details. You are looking for flight \n\n from: "+fCity+ "\n\n to :"+tCity+"\n\nfor date :"+DepDate+"\n\n Number of Passengers:"+number,  
            "elements": [                    
              {
                "title": "Yes"           
              },
              {
                "title": "No"      
              }
            ]
          }
        }
      };
    
    
    
    
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonQuick),
          },
        },
      };
    }

    else if(current_intent === 'Yes')
    {
      var sessionAttributes = request.sessionAttributes;
    
    
      var fCity = request.sessionAttributes.FromCity;
      var tCity =request.sessionAttributes.ToCity;
    
        var title = "Flights "+fCity+" - "+tCity;
        
        
         let jsonList2 = {
          "templateType":"ListPicker",                       
          "version":"1.0",                                   
          "data":{                                           
         
             "content":{                                        
                "title":title, 
                "subtitle":"Tap to select option",
                "imageType":"URL",                       
                "imageData":"https://www.goindigo.in/content/dam/indigov2/6e-website/downloadapp/Feature-Image.png",                  
                "imageDescription":"Select any of the option",
                "elements":[                                   
                   {
                      "title":"Select 1",                      
                     "subtitle":"13:40 - 21:40, ✈️ 6E919, 65$",
                      "imageType":"URL",
                      "imageData":"https://static.thenounproject.com/png/3652216-200.png"
                   },
                   {
                      "title":"Select 2",                         
                    "subtitle":"6:10 - 11:40, ✈️ 6E920, 55$",
                      "imageType":"URL",                  
                      "imageData":"https://static.thenounproject.com/png/3652216-200.png",           
                   },
                    {
                      "title":"Select 3",                         
                    "subtitle":"17:40 - 21:40, ✈️ 6E921, 105$",
                      "imageType":"URL",                  
                      "imageData":"https://static.thenounproject.com/png/3652216-200.png",            
                      "imageDescription":"Banana"
                   }
                   ,
                   {
                    "title":"Select 4",                         
                    "subtitle":"11:40 - 14:40, ✈️ 6E922, 70$",
                    "imageType":"URL",                  
                    "imageData":"https://static.thenounproject.com/png/3652216-200.png",            
                    "imageDescription":"Banana"
                 }
                ]
             }
         }
       };
    
    
    
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonList2),
          },
        },
      };
    }

    else if(current_intent === 'FlightSelect')
    {
      var sessionAttributes = request.sessionAttributes;
     var FSelect =request.currentIntent.slots.FSelect;
      sessionAttributes.FlightSelected = FSelect;
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonCarousel),
          },
        },
      };
    }

    else if(current_intent === 'AskPNR')
    {
      var sessionAttributes = request.sessionAttributes;
      
       let jsonQuick1 = {
        "templateType": "QuickReply",        
        "version": "1.0",                    
        "data": {                            
          "content": {                       
            "title": "Thank you for sharing the details. What you would like to do?",  
            "elements": [                    
              {
                "title": "Change Flight Date"           
              },
              {
                "title": "Cancel Flight Booking"      
              }
            ]
          }
        }
      };
    
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonQuick1),
          },
        },
      };
    }

    else { 
      var sessionAttributes = request.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState :"Fulfilled",
          message: {
            contentType: "PlainText",
            content: "Selected "+current_intent,
          },
        },
      };

    }


    // if(current_intent === 'InteractiveMessageIntent')
    // {
    //   var sessionAttributes = request.sessionAttributes;
    //   var slots = request.currentIntent.slots;
    //   var slotToElicit = SLOTS.ACTION;
    //   return {
    //     sessionAttributes,
    //     dialogAction: {
    //       type: "Close",
    //       fulfillmentState :"Fulfilled",
    //       message: {
    //         contentType: "CustomPayload",
    //         content: JSON.stringify(jsonList),
    //       },
    //     },
    //   };
    // }


    // if(current_intent === 'InteractiveMessageIntent')
    // {
    //   var sessionAttributes = request.sessionAttributes;
    //   var slots = request.currentIntent.slots;
    //   var slotToElicit = SLOTS.ACTION;
    //   return {
    //     sessionAttributes,
    //     dialogAction: {
    //       type: "ElicitSlot",
    //       "intentName" : current_intent,
    //       slots,
    //       slotToElicit,
    //       message: {
    //         contentType: "CustomPayload",
    //         content: JSON.stringify(jsonList),
    //       },
    //     },
    //   };
    // }
  
  
  
  }