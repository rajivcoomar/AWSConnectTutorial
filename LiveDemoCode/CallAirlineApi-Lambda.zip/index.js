const axios = require('axios');
const APIKEY = process.env.APIKEY;

exports.handler = async (event, context) => {
  console.log(event.Details.Parameters.FlightNumber);
  
  var flightNo = event.Details.Parameters.FlightNumber;
  

  const config = {
    method: 'get',
    url: `http://api.aviationstack.com/v1/flights?access_key=${APIKEY}&flight_iata=${flightNo}`,
    headers: {},
  };

  

  try {
    const response = await axios(config);
    const data = response.data;
    const flightData = data.data;

    console.log(JSON.stringify(data));

    const responseObj = {};
    let msgString = "Here is the status of Flight Number:";

    for (let i = 0; i < flightData.length; i++) {
      const flight = flightData[i];
      const flight_date = flight.flight_date;
      const flight_status = flight.flight_status;
      const departure = flight.departure.airport;
      const arrival = flight.arrival.airport;
      const airline = flight.airline.name;

      console.log(flight_date);
      console.log(flight_status);
      console.log(departure);
      console.log(arrival);
      console.log(airline);

      msgString += `\n\nDated: ${flight_date}\nAirline: ${airline}\nFrom: ${departure}\nTo: ${arrival}\nStatus: ${flight_status}`;
    }

    responseObj.msgString = msgString;
    console.log('returnObject Final ' + JSON.stringify(responseObj));

    return responseObj;
  } catch (error) {
    console.error(error);
    throw error; // This will allow AWS Lambda to handle the error
  }
};
