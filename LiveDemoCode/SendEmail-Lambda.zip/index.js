var aws = require('aws-sdk');
var ses = new aws.SES({region: 'eu-west-2'});
exports.handler = (event, context, callback) => {
  
     console.log(event)
    sendMail("Flight Ticket is Cancelled");
};

async function sendMail(subject) {
  const emailParams = {
        Destination: {
          ToAddresses: ["bot.coomar@gmail.com"],
        },
        Message: {
          Body: {
            Text: { Data: "Your flight booking is cancelled. You will recive refund into your payment source within next 7-10 working days." },
          },
          Subject: { Data: subject },
        },
        Source: "rajivcoomar@gmail.com",
  };
      
  try {
        let key = await ses.sendEmail(emailParams).promise();
        console.log("MAIL SENT SUCCESSFULLY!!");      
  } catch (e) {
        console.log("FAILURE IN SENDING MAIL!!", e);
      }  
  return;
}