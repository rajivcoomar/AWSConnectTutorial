  function elicitIntent(event, message) {
    return {
        sessionState: {
            dialogAction: {
                type: "ElicitIntent"
            },
            sessionAttributes: {}
        },
        messages: message ? [message] : [],
        requestAttributes: event.requestAttributes || null
    };
}

function close(event, fulfillmentState, message) {
    event.sessionState.intent.state = fulfillmentState;
    return {
        sessionState: {
            sessionAttributes: {},
            dialogAction: {
                type: "Close"
            },
            intent: event.sessionState.intent
        },
        messages: message ? [message] : [],
        sessionId: event.sessionId,
        requestAttributes: event.requestAttributes || null
    };
}
  
  
  
  /* MAIN HANDLER */
  exports.handler  = async function(event, context) {
    try {
      console.log(`Request received: ${JSON.stringify(event)}`);
      let response = handleRequest(event);
      console.log(`Returning response: ${JSON.stringify(response)}`);
      return response;
    } catch (err) {
      console.error(`Error processing Lex request:`, err);
      var sessionAttributes = event.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState : "FAILED",
          message: {
            contentType: "PlainText",
            content: "Error in Lex Lambda",
          },
        },
      };
     }
  };
  
  /* PROCESS INBOUND MESSAGE */
  function handleRequest(request) {
  
    let current_intent = request.sessionState.intent.name;

    let jsonList = {
      "templateType":"ListPicker",                       
      "version":"1.0",                                   
      "data":{                                           
     
         "content":{                                        
            "title":"How may I assist you?", 
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://www.goindigo.in/content/dam/indigov2/6e-website/downloadapp/Feature-Image.png",                  
            "imageDescription":"Select any of the option",
            "elements":[                                   
               {
                  "title":"Book a Flight",                      
                 
                  "imageType":"URL",
                  "imageData":"https://cdn0.iconfinder.com/data/icons/travel-line-color-this-is-vacation-time/512/Flight_booking-512.png"
               },
               {
                  "title":"Flight Information",                         
                
                  "imageType":"URL",                  
                  "imageData":"https://static.thenounproject.com/png/3652216-200.png",           
               },
                {
                  "title":"Manage Booking",                         
                
                  "imageType":"URL",                  
                  "imageData":"https://cdn0.iconfinder.com/data/icons/miscellaneous-22-line/128/booking_travel_tourism_online_reservation_ticket_air-ticket-512.png",            
                  "imageDescription":"Banana"
               }
               ,
               {
                "title":"Contact Us",                         
             
                "imageType":"URL",                  
                "imageData":"https://cdn-icons-png.flaticon.com/512/3095/3095583.png",            
                "imageDescription":"Banana"
             }
            ]
         }
     }
   };

   if(current_intent === 'Help')
    {
       //return helpIntentResponse(request);
        const message = {
          contentType: "CustomPayload",
          content: JSON.stringify(jsonList)
        };
       return elicitIntent(request,  message);
    
    }
    else { 
       const message = {
        contentType: "PlainText",
        content: "You have selected the 'help' intent. How can I assist you today?"
      };
      return close(request, "Fulfilled", message);

    }

  }