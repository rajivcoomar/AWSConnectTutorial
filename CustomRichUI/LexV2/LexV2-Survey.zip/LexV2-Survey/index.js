  function elicitIntent(event, message) {
    return {
        sessionState: {
            dialogAction: {
                type: "ElicitIntent"
            },
            sessionAttributes: {}
        },
        messages: message ? [message] : [],
        requestAttributes: event.requestAttributes || null
    };
}

function close(event, fulfillmentState, message) {
    event.sessionState.intent.state = fulfillmentState;
    return {
        sessionState: {
            sessionAttributes: {},
            dialogAction: {
                type: "Close"
            },
            intent: event.sessionState.intent
        },
        messages: message ? [message] : [],
        sessionId: event.sessionId,
        requestAttributes: event.requestAttributes || null
    };
}
  
  
  
  /* MAIN HANDLER */
  exports.handler  = async function(event, context) {
    try {
      console.log(`Request received: ${JSON.stringify(event)}`);
      let response = handleRequest(event);
      console.log(`Returning response: ${JSON.stringify(response)}`);
      return response;
    } catch (err) {
      console.error(`Error processing Lex request:`, err);
      var sessionAttributes = event.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState : "FAILED",
          message: {
            contentType: "PlainText",
            content: "Error in Lex Lambda",
          },
        },
      };
     }
  };
  
  /* PROCESS INBOUND MESSAGE */
  function handleRequest(request) {
  
    let current_intent = request.sessionState.intent.name;

    let jsonList = {
      "templateType":"ListPicker",                       
      "version":"1.0",                                   
      "data":{                                           
     
         "content":{                                        
            "title":"How may I assist you?", 
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://www.goindigo.in/content/dam/indigov2/6e-website/downloadapp/Feature-Image.png",                  
            "imageDescription":"Select any of the option",
            "elements":[                                   
               {
                  "title":"Good",                      
                 
                  "imageType":"URL",
                  "imageData":"https://www.shutterstock.com/image-vector/feedback-emoji-emoticons-set-rating-260nw-2683113361.jpg"
               },
               {
                  "title":"Average",                         
                
                  "imageType":"URL",                  
                  "imageData":"https://www.shutterstock.com/image-vector/feedback-emoji-emoticons-set-rating-260nw-2683113393.jpg",           
               },
                {
                  "title":"Bad",                         
                
                  "imageType":"URL",                  
                  "imageData":"https://www.shutterstock.com/image-vector/sad-face-icon-260nw-582975013.jpg",            
                  "imageDescription":"Banana"
               }
               
            ]
         }
     }
   };

   if(current_intent === 'Help')
    {
       //return helpIntentResponse(request);
        const message = {
          contentType: "CustomPayload",
          content: JSON.stringify(jsonList)
        };
       return elicitIntent(request,  message);
    
    }
    else { 
       const message = {
        contentType: "PlainText",
        content: "You have selected the 'help' intent. How can I assist you today?"
      };
      return close(request, "Fulfilled", message);

    }

  }