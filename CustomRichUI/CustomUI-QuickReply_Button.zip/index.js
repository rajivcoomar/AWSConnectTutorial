  
  /* MAIN HANDLER */
  exports.handler  = async function(event, context) {
    try {
      console.log(`Request received: ${JSON.stringify(event)}`);
      let response = handleRequest(event);
      console.log(`Returning response: ${JSON.stringify(response)}`);
      return response;
    } catch (err) {
      console.error(`Error processing Lex request:`, err);
      var sessionAttributes = event.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState : "FAILED",
          message: {
            contentType: "PlainText",
            content: "Error in Lex Lambda",
          },
        },
      };
     }
  };
  
  /* PROCESS INBOUND MESSAGE */
  function handleRequest(request) {
  
    let current_intent = request.currentIntent.name;
    let inputTranscript = request.inputTranscript;

    let jsonList = {
      "templateType":"ListPicker",                       
      "version":"1.0",                                   
      "data":{                                           
     
         "content":{                                        
            "title":"What produce would you like to buy?", 
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://interactive-msg.s3-us-west-2.amazonaws.com/fruit_34.3kb.jpg",                  
            "imageDescription":"Select a produce to buy",
            "elements":[                                   
               {
                  "title":"Book Flight Option 1",                          
                  "subtitle":"$1.00",
                  "imageType":"URL",
                  "imageData":"https://interactive-message-testing.s3-us-west-2.amazonaws.com/apple_4.2kb.jpg"
               },
               {
                  "title":"Book Flight Option 2",                         
                  "subtitle":"$1.50",
                  "imageType":"URL",                  
                  "imageData":"https://interactive-message-testing.s3-us-west-2.amazonaws.com/orange_17.7kb.jpg",           
               }
            ]
         }
     }
   };
   
    let jsonList2 = {
      "templateType":"ListPicker",                       
      "version":"1.0",                                   
      "data":{                                           
     
         "content":{                                        
            "title":"Please select the type of Apple?", 
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://interactive-message-testing.s3-us-west-2.amazonaws.com/apple_4.2kb.jpg",                  
            "imageDescription":"Select a produce to buy",
            "elements":[                                   
               {
                  "title":"Fuji",                          
                  "subtitle":"$1.00 per KG",
                  "imageType":"URL",
                  "imageData":"https://media.istockphoto.com/id/1292220869/photo/fuji-apple-with-green-leaf-isolated-on-white-background.jpg?s=612x612&w=0&k=20&c=mXjsdgiFNcAot9EqU6y2PxVkkwE1SKbLJwIjTwXg7XE="
               },
               {
                  "title":"Red Delicious",                         
                  "subtitle":"$1.50 per KG",
                  "imageType":"URL",                  
                  "imageData":"https://waapple.org/wp-content/uploads/2021/06/red-delicions-with-shadow.png",           
               },
                {
                  "title":"Mutsu",                         
                  "subtitle":"$10.00 per KG",
                  "imageType":"URL",                  
                  "imageData":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSEhMVFRUVFxUXFRcXFxcVFRUVFxUXFhUXFRUYHSggGBolGxgXITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGy0lICUtLTUtLS4tLS0tLSstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAwQBAgUGB//EADsQAAIBAgMFBAcGBQUAAAAAAAABAgMRBCExBRJBUWEGE3GRIjKBobHR8BRCUnLB4QdigrLCFSM0c6L/xAAaAQEAAwEBAQAAAAAAAAAAAAAAAQIDBQQG/8QAJBEBAAIBBAICAwEBAAAAAAAAAAECEQMEEiEFMRNBUXGxImH/2gAMAwEAAhEDEQA/APuIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFisTCnCVSpJRhFXlJuyS8QJQfNcZ/E6+JhGjTl9nhOKqzlH0pxk3FuMfuxXrc20lZZ3+lFKalbZwtas19gALqgAAAAAAAAAAAAAAAAAAAAAAAAOVtHtFhqDtOonL8MfSl7bae2x5/GfxAik+6otvg5tL/zG9/Myvr6dPcpxL2oPlGJ7XYmbzquC5QSil7dfeVJ4mdT16k5/mlKXxZ4r+SpHqsp4vq9faVGHr1acfGUU/K5RrdqsJHJ1k/CM5fBHzaNJLQsfZbnnt5W31WE8Xu32xwazdRpc3Tnb+0+ebe7Qy2liY0Yy7rDRd7yvZLjUqJfea9WPXxZzNtXlUhh6ecpNX5aXz6KN5P2HTwuzo0YqCztdt8ZPi39ZGWpv73ri2O/w1rEUjl9vabF2DsuO7udzVmt1705KU24yUk2m+EknpwR64+MV2vEsbN21Xw7Xd1GkvuPOD/penssz1aPkKx1NcfplPf2+vg81sHtfSr2hUtSqdX6Evyy4Po/eelOnS9bxmqsxgABZAAAAAAAAAAAAAAAAAAYk7K7yS1AixeKhSi5zkoxWr+XN9DwW3u1FSreMG6dPkvXkv5mtF0XvIO0u2XiKlk7U433Fz5ya5v3L2lDDYRt+kcXd76ZnjWev6j/kKapN6KxHVwb5nYlT5IjlSzzz6HM+aV4iXn62EkupU7+dN31XE9JOlfgVp4VPgX+SLe1+SrhNoqR0qGJWd9Fn7EcyeyIXuk0+mXu0JaeAdmt52atfK/UraKyjpr2WW/Ur4iX4tyN8rXtOfxgl4Mu47GJu0dDTAbPVKHdxk7Xbd2m25Scm3lzZJKgkTM15I1bTaXPk5PRELUjqSp+ZFUh09peLsu4cyVR8Tt7E7W4jD2W93lNfcnnl/LLWPw6HMnRNPs/Jm1NS1ZzWWkWz7fYNg7eo4uN6btJetB5Sj811R1D4vgZTpSU6cnGcdJL4NcV0PqPZvbccVTu7RqR9eP8AlH+V+7Q7G33HydW9omHXAB6kAAAAAAAAAAAAAAcDtjj+7o7iedTL+let+i9p3zwXa/Eb+IceEEorx1fx9x5N7q/HpTj76HEw9BvM7eHwd0RYHDnZo30t7ep8zP8AqWunTCq8Fwt8jZ4BWvZJ9NDopZCosi3CGuHnK+EeeVii6OeaPVVKEbaZvNnKxWGV3czmJqparjyprQ2hC1r6vIu06Fm3bUy6OnAZU4qfd5rkZqRLiRVxMrNX9xGeyYU6sE31IqscieazIqvU1rKmFGS56BFmcbkW4bRZXj22gzobLxcqNSNSGsdVwkuMX0fy5HNgizRZ6dPU7y1fV8JiY1IRqRd4yV18n1JjyvYvG+tRf54/5L4PzPVHc0r86xKkgANEAAAAAAAAAAAHzeu9+rKb4yb83c+h4udoTfKMn5Jnz+krHI8tbqsftMQ6GCjZF+greb/c5dKdvMvUavB38f3OJp2eiPS9E1lrlbr+mRrSl1M72fG7N0tar4FPFZrQuVbWzKWIlw+rGVxXnNaoiqST0NpvpkQzbtlZmOVZYVPkR4iHFksGR1I/uVmSIVJ6FecU1zX0y3OJA4W0L1lWY7V5Q4GkkTTgRSRtEqo0S0yOSNoGtLYlZ1ti4nu6sJ8pK/5X6Mvc2fST5RBn1DAVd+nCX4oxfmkdzZXzEwzsnAB7lQAAAAAAAAAAVNrP/Yq/kl8GeGox9E91tSN6NT8kvgzxFGPE4nlvdVqpKUuaLVyvF8CTicKYbRK3RralqEsjmUnn1J6U3bPga11FoWpsoYlplqc79CpNq7f19Zkalkqzdv3K/fXXVX+kT1OT8SKdNamMSjDenmZqRdjNCGWZtOXtC8V6UavErPJZl+rEqVS9WdoV5IjkSTIprJm1VJRy0EJXDNDSDKzFn0ns9K+Gpflt5No+ZU2fSuzP/FpeD/uZ2PHz/qf0pZ1AAdVQAAAAAAAAAAGtSF00+Ka8zwdH0bp6p2/Q98eM2zR3K81wl6S/q199zleVpnTi34WrPam3nZfXiTUpWK7mSKfwPnZaw2lWz+uLJFPn9MgfFm6llbn8SkrRKSVT4iXMjRpOZC2UVW99SSOZqzNElNVmisshJC9lyNKk8iWqCrHiU6zJq1R36FesTVlZXnyImS1SKRvDGUUjWxuas0hDekz6fsCFsNS/In55/qfMqa5H1nDUtyEY/hil5Kx2fHR7lWyQAHUUAAAAAAAAAAAOB2qw+UKi4Pdfg8177+Z3yDHYZVKcoP7y8nwfmY7jS+TTmo8EtTbQjkmm08mrprqtRc+QvXE4axLdSu7GUteZotDaNvP61M8LN3UfIrzmyS5pIYJk3zenLQr2zDqCYTW2FqnPXNvj4dDWdQgUzWciML8m83zK9R8TLnkRyncvWFZlHNmszdyNGawpKJmtjeTIpM1hV1+zmH7zEUo8FLefhH0v0t7T6aeM/h9hL95Wf/XH3Sn/AI+89mfQ7GnHSz+VbSAA9ioAAAAAAAAAAAAA8l2pwW5NVEsp69JL5r4M4bZ9Bx+EVWnKD46Pk+DPAYii4ScJK0ouzOB5Hb8b849T/Voli+QjM0TMKRyJhfLLnqhvEU5Z5mimMIy3k+NzST5GakiK/ImIMpTXeuY3jXeGDJJkSN2QtmkQZbtmkpmjlYhlMvWpNkkpkKblJRiryk0klxbyS8yKdSx6n+Hmye8qPEzXo07qHWo1m/CKfnLoevQ0JvaIZzbPT3OxsAqFGFJfdWb5yecn7W2XQD6KIiIxAAAkAAAAAAAAAAAAAA4vaLZPervIL046r8S+aO0YuZ6mnXUrNbD5jM0cz2HaDYSqXqUsp6yjopdVyl8TxlaLTaaaa1Tya8UfO7naW0rYlOWJSMOZFKRpvHniinJY3jDmQqRiUyOCYslczHeEMpGrqExQ5JZTsQSmYnMrzmaVoibN51CvOoR1apA5ttKKbbdklm23okuLPRXTUm67s7BzxNaFGn60nrwjH70n0S+XE+0bNwMKFKFKmrRgrLm+bfVu7fieb7FbEjhKblOzrVEt967i4Qi/i+L8EemVdHZ22j8dcz7lesYTgiVU2Uz0rNwa7xm4GQYuZAAAAAAABq2Bm5q5mspEFSYEsqpBUxVivVqHPxFRgWcRtKx57bGLp1M5LPhJa/ub4q7OTiaDZW1YtGLQOTWxUYu29bxyDma4vZbkUY7MqQ9VtdOHkeDU8fWe6ThWaugpms5lZQqrVJ+4xLf/AA+/9jyzsdWJ9KcbJ1UNZVCtJVORo6dTki0bLU/CONlidUr1axj7NUfH3GFs9vVs2rsbfeD45Q77k7I72w1Ci9/Wf4nw6R5eJQoYCxepUGevS29ad+5XikQ9Nh9rvmdGhtO/E8rRpsv0Ez0LvU0seWqeLPO0Gy9SkwO3CuSxqnKpyLMJgdBVDdSKUZksZgWbmSFSN1IDcGtwBsas2AEMkQziWnE1cAOfUplapQOq6ZpKiBw6mFK88F0PQSoEbw4HnJ4DoQy2d0PTPDGjwoHl5bN6Ectm9D1Twpo8KB5R7M6Gv+m9D1bwhq8IB5X/AE3oZWzuh6j7J0H2QDzS2f0JI4Doei+ymVhQOHDBdCxTwp1lhzdUAOfToFiFItqibqkBBCBNGJJGmbqAGsUSxRlQN1EAjdBI2SAAzYASAADAMgDWw3TYAabpjcJDAEbpmrpk1hYCDujHdFiwsBW7ox3JZsLAVe5MdyW7DdAqdyO5LW6N0Cr3Q7otbo3QK3dme7LG6N0CFQMqBNuiwEaiZUTexkDVIzYyAMWBsAAAAAAAAAAAAAAAAAMAAAAAAAAAAAAAAAAAADIAAAAD/9k=",            
                  "imageDescription":"Banana"
               }
               
            ]
         }
     }
   };
   
    let jsonCarousel ={
    "templateType": "Carousel",            
    "version": "1.0",                      
    "data": {                              
        "content": {                           
          "title": "View our popular destinations",   
          "elements": [                               
          {
            "templateIdentifier": "template0",        
            "templateType": "Panel",
            "version": "1.0",
            "data": {
              "content": {
                "title": "Saver",
                "subtitle": "Tap to select option",
                "elements": [
                  {
                    "title": "Book flights"  //Training phrase in intent - templateIdentifier template listTitle California selectionText Book flights
                  },
                  {
                    "title": "Book hotels",
                    "type": "hyperlink",
                    "url": "https://www.example.com/Flights"
                  }
                ]
              }
            }
          },
          {
            "templateIdentifier": "template1",   
            "templateType": "Panel",
            "version": "1.0",
            "data": {
              "content": {
                "title": "New York",
                "subtitle": "Tap to select option",
                "elements": [
                  {
                    "title": "Book flights"   //Training phrase in intent - templateIdentifier template listTitle New York selectionText Book flights
                  },
                 {
                    "title": "Book hotels",
                    "type": "hyperlink",
                    "url": "https://www.example.com/Flights"
                  }
                ]
              }
            }
          }
        ]
      }
    }
  };


var buttonJSON = {
  "templateType": "QuickReply",        
  "version": "1.0",                    
  "data": {                           
    "content": {                       
      "title": "Which department would you like?",  
      "elements": [                   
        {
          "title": "Billing"           
        },
        {
          "title": "Cancellation"      
        },
        {
          "title": "New Service"       
        }
      ]
    }
  }
}
  


   if(current_intent === 'MainMenu')
    {
      var sessionAttributes = request.sessionAttributes;
      sessionAttributes.NumberValue = request.currentIntent.slots.value;
     
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(buttonJSON),
          },
        },
      };
    }

    else if(current_intent === 'Book')
    {
      var sessionAttributes = request.sessionAttributes;
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonCarousel),
          },
        },
      };
    }

  

    else { 
      var sessionAttributes = request.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState :"Fulfilled",
          message: {
            contentType: "PlainText",
            content: inputTranscript,
          },
        },
      };

    }


    // if(current_intent === 'InteractiveMessageIntent')
    // {
    //   var sessionAttributes = request.sessionAttributes;
    //   var slots = request.currentIntent.slots;
    //   var slotToElicit = SLOTS.ACTION;
    //   return {
    //     sessionAttributes,
    //     dialogAction: {
    //       type: "Close",
    //       fulfillmentState :"Fulfilled",
    //       message: {
    //         contentType: "CustomPayload",
    //         content: JSON.stringify(jsonList),
    //       },
    //     },
    //   };
    // }


    // if(current_intent === 'InteractiveMessageIntent')
    // {
    //   var sessionAttributes = request.sessionAttributes;
    //   var slots = request.currentIntent.slots;
    //   var slotToElicit = SLOTS.ACTION;
    //   return {
    //     sessionAttributes,
    //     dialogAction: {
    //       type: "ElicitSlot",
    //       "intentName" : current_intent,
    //       slots,
    //       slotToElicit,
    //       message: {
    //         contentType: "CustomPayload",
    //         content: JSON.stringify(jsonList),
    //       },
    //     },
    //   };
    // }
  
  
  
  }