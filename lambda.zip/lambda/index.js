
var axios = require('axios');

exports.handler = async (event) => {
    // TODO implement
  var config = {
  method: 'get',
  url: 'https://www.mohfw.gov.in/data/datanew.json',
  headers: { }
	};

	axios(config)
	.then(function (response) {
	 // console.log(JSON.stringify(response.data));
	  console.log(JSON.stringify(response.data));
  
        var responseObj={};
        var data = JSON.parse(JSON.stringify(response.data));
        responseObj.active = data[36].active;
        responseObj.positive = data[36].positive;
        responseObj.cured = data[36].cured;
        responseObj.death = data[36].death;
        console.log(responseObj.active);
        console.log(responseObj.positive);
        console.log(responseObj.cured);
        console.log(responseObj.death);
        
         console.log('returnObject Final ' + JSON.stringify(responseObj));
        
        return responseObj;
	})
	.catch(function (error) {
	  console.log(error);
	});
};
