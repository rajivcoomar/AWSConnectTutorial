const AWS = require('aws-sdk');
const axios = require('axios');
const enableLogging =  'true';
const modelId = "anthropic.claude-3-haiku-20240307-v1:0";
const cheerio = require('cheerio');
const connectClient = new AWS.Connect();
const s3Client = new AWS.S3();
const bedrock = new AWS.BedrockRuntime();
const comprehend = new AWS.Comprehend();

exports.handler = async (event) => {
    try {
        console.log(JSON.stringify(event));
        const myEvent = event.Details.ContactData;
        const instName = process.env.instName;
        const emailBucket = process.env.connectBucket;
        
        const emailContent = await extractEmailContent(myEvent);
        console.log("email :" + emailContent);
        const textContent = extractEmailContent_text(emailContent);
        console.log("email textContent:" + textContent);
        const instruction = `
        Analyze the following email message and provide the following information in a JSON format:
        1. Intents: Detect all intentions of why the person is reaching out.
        2. PII: Detect if any Personally Identifiable Information is present, and if so, extract:
           - Phone number
           - Email address
           - Name
           - Address
           - Account number
           - Order Number
           - Any other PII found
        3. User intent: Determine the primary reason for contact to assist with routing. It can be only 'homeloan' or 'orderstatus' or 'faq' or 'other'.

        Output format:
        {
            "intents": ["intent1", "intent2", ...],
            "pii_detected": true|false,
            "extracted_info": {
                "phone_number": "...",
                "email_address": "...",
                "name": "...",
                "address": "...",
                "account_number": "...",
                "order_number": "...",
                "other_pii": [...]
            },
            "user_intent": "primary_intent_for_routing"
        }

        Provide only the JSON output, no additional text or explanations.
        `;
        //const languageCode = await detectLanguage(emailContent);
        
        const bedrockResult = await callBedrock(instruction, emailContent);
        

        if (bedrockResult.success) {
            const resultData = bedrockResult.data;
            console.log(resultData);
            return {
                intent1: resultData.intents.length ? resultData.intents[0] : '',
                pii_detected: resultData.pii_detected ? 'true' : 'false',
                user_intent: resultData.user_intent,
                phone_number: resultData.extracted_info.phone_number || '',
                email_address: resultData.extracted_info.email_address || '',
                name: resultData.extracted_info.name || '',
                address: resultData.extracted_info.address || '',
                account_number: resultData.extracted_info.account_number || '',
                order_number: resultData.extracted_info.order_number || '',
                other_pii: resultData.extracted_info.other_pii ? resultData.extracted_info.other_pii.join(',') : ''
            };
        } else {
            return { error: 'An error occurred while processing the email' };
        }
    } catch (error) {
        console.error("Lambda Handler Error:", error);
        return { error: 'Internal Server Error' };
    }
};

function extractEmailContent_text(htmlContent) {
    const $ = cheerio.load(htmlContent);
    return $('body').text().replace(/\s+/g, ' ').trim();
}

async function extractEmailContent(myEvent) {
    try {
        if (enableLogging) console.log("Incoming event:", JSON.stringify(myEvent, null, 2));

        let fileId = null;
        if (myEvent.References) {
            for (let [key, value] of Object.entries(myEvent.References)) {
                if (value.Type === "EMAIL_MESSAGE") {
                    fileId = value.Value || value.Reference || value.Id || key;
                    break;
                }
            }
        }
        
        if (!fileId) {
            const response = await connectClient.listContactReferences({
                InstanceId: myEvent.InstanceARN.split('/')[1],
                ContactId: myEvent.ContactId,
                ReferenceTypes: ['EMAIL_MESSAGE']
            }).promise();
            
            if (response.ReferenceSummaryList.length) {
                const emailRef = response.ReferenceSummaryList[0];
                fileId = emailRef.Value || emailRef.Reference || emailRef.Name || emailRef.Id;
            }
        }
        
        if (!fileId) throw new Error("Could not find file ID in email reference");
        
        const fileResponse = await connectClient.getAttachedFile({
            InstanceId: myEvent.InstanceARN.split('/')[1],
            FileId: fileId,
            AssociatedResourceArn: `${myEvent.InstanceARN}/contact/${myEvent.ContactId}`
        }).promise();
        
        if (!fileResponse.DownloadUrlMetadata || !fileResponse.DownloadUrlMetadata.Url) {
            throw new Error("Failed to get download URL for email content");
        }
        
        const downloadUrl = fileResponse.DownloadUrlMetadata.Url;
        const response = await axios.get(downloadUrl);
        return response.data.messageContent || response.data.content || response.data.body || response.data.text || "";
    } catch (error) {
        console.error("extractEmailContent Error:", error);
        throw error;
    }
}

async function detectLanguage(text) {
    try {
        const response = await comprehend.detectDominantLanguage({ Text: text }).promise();
        return response.Languages[0].LanguageCode;
    } catch (error) {
        console.error("detectLanguage Error:", error);
        return 'unknown';
    }
}

async function callBedrock(instruction, emailContent) {
    try {
        const requestBody = JSON.stringify({
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 1000,
            system: instruction,
            messages: [{ role: "user", content: emailContent }],
            temperature: 0
        });
        
        const response = await bedrock.invokeModel({
            body: requestBody,
            modelId: modelId,
            accept: 'application/json',
            contentType: 'application/json'
        }).promise();
        
        const responseBody = JSON.parse(response.body.toString());
        const result = JSON.parse(responseBody.content[0].text);
        
        return { success: true, data: result };
    } catch (error) {
        console.error("callBedrock Error:", error);
        return { success: false, data: error.message };
    }
}
