 /* MAIN HANDLER */
  exports.handler  = async function(event, context) {
    try {
      console.log(`Request received: ${JSON.stringify(event)}`);
      
      //Do code here
      
      const message = {
        contentType: "PlainText",
        content: "response coming from Lambda"
      };
      
      
    event.sessionState.intent.state = "Fulfilled";
    return {
        sessionState: {
            sessionAttributes: {},
            dialogAction: {
                type: "Close"
            },
            intent: event.sessionState.intent
        },
        messages: [message] ,
        sessionId: event.sessionId,
        requestAttributes: event.requestAttributes || null
    };
      
     // return response;
    } catch (err) {
      console.error(`Error processing Lex request:`, err);
      var sessionAttributes = event.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState : "FAILED",
          message: {
            contentType: "PlainText",
            content: "Error in Lex Lambda",
          },
        },
      };
     }
  };
  
 