
var aws = require('aws-sdk');
var db = new aws.DynamoDB({
  region: 'eu-west-2'
});



const queryMyThings = async (event,day) => { 
 var params = {
      Key: {
      "Days": {
         S: day
        }
      }, 
      TableName: "OfficeHourCheck"
     };

    return await db.getItem(params).promise();

}


const queryCustomerInfo = async (event,phonenumber) => { 
 var params = {
      Key: {
      "UserPhoneNo": {
         S: phonenumber
        }
      }, 
      TableName: "CustomerInfo"
     };

    return await db.getItem(params).promise();

}

exports.handler = async (event) => {
  console.log(event);
  //console.log(event.Details.Parameters.UserPhoneNumber);

  if(event && event.Details && event.Details.Parameters 
    && event.Details.Parameters.Type && event.Details.Parameters.Type == 'CRM')
  {
      var phoneNumber = event.Details.Parameters.UserPhoneNumber;

      var dbOutput =  await queryCustomerInfo(event,phoneNumber);
      console.log(dbOutput);

      let returnObject = {};

      if(dbOutput != {})
      {
        var FirstName = dbOutput.Item.FirstName.S;
        var LastName = dbOutput.Item.LastName.S;
        var SecurityCode = dbOutput.Item.SecurityCode.N;

        returnObject.isFound = true;
        returnObject.FirstName = FirstName;
        returnObject.LastName = LastName;
        returnObject.SecurityCode = SecurityCode;
      }
      else
      {
        returnObject.isFound = false;

      }

      return returnObject;
  }
  else
  {

      var memberID = event.inputTranscript;
      console.log(memberID);

      let regex = new RegExp(/^[A-Za-z]{3}[1-9]{7}$/);
      var found = regex.test(memberID);
         console.log(found);
         
         var resultMatch = "";
         var retObj ;
         var sessionAttributes = event.sessionState.sessionAttributes;
         
         var userName = sessionAttributes.UserName;
         console.log(userName);
         
         if(found == false)
         {
          if(sessionAttributes && sessionAttributes.failedCount)
          {
            var count = sessionAttributes.failedCount;
            console.log(count);
            if(count == 3)
            {
              event.sessionState.intent.state = "Failed";
                return {
                  "sessionState": {
                  "dialogAction": {   
                            "type": "Close"
                              },
                              "intent": event.sessionState.intent
                                }
                            }
            }
              count++;
              sessionAttributes.failedCount = count;
            }
            else
            {
              sessionAttributes.failedCount = 1;
            }

         
           retObj =    {
            "sessionState": {
                        sessionAttributes,
                        "dialogAction": {
                            "slotToElicit": "MemberID",
                            "type": "ElicitSlot"
                        },
                        "intent": event.sessionState.intent
                    }
                }
                
         
         }
         else
         {
          event.sessionState.intent.state = "Fulfilled";

          retObj = {
            "sessionState": {
              sessionAttributes,
             "dialogAction": {   
                       "type": "Close"
                         },
                          "intent": event.sessionState.intent
                           }
                      }
          
         }

        
      console.log(retObj);
     return retObj;
  }

    // TODO implement
 /*   var currentDate = new Date() ;
     console.log(currentDate);
    var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    var day = days[currentDate.getDay() ];
    
    console.log(day);
    
   var output =  await queryMyThings(event,day);
   
   
   console.log(output);
  
   var startTime = output.Item.StartTime.S;
   console.log(startTime);
   var endTime = output.Item.EndTime.S;
   console.log(endTime);
  
    var startDate = new Date(currentDate.getTime());
    startDate.setHours(startTime.split(":")[0]);
    startDate.setMinutes(startTime.split(":")[1]);
   
    
    var endDate = new Date(currentDate.getTime());
    endDate.setHours(endTime.split(":")[0]);
    endDate.setMinutes(endTime.split(":")[1]);
   
 console.log(startDate);
 console.log(endDate);
  console.log(currentDate);
     let returnObject = {};
   
     console.log(startDate < currentDate);
      console.log(endDate > currentDate);
    var valid = startDate > currentDate && endDate < currentDate;
      returnObject.isOfficeOpen = true;
    console.log(valid);

    */
    
    /*
    console.log(event.inputTranscript);
    
    var upiID = event.inputTranscript;
    
    let regex = new RegExp(/^[\w\.\-_]{3,}@[a-zA-Z]{3,}/);
    var found = regex.test(upiID);
 			console.log(found);
 			
 			var resultMatch = "";
 			if(found == false)
 			{
 			  resultMatch = "Failed";
 			}
 			else
 			{
 				resultMatch = "Fulfilled";
 			}
    
   return {
    "sessionState": {
     "dialogAction": {   
               "type": "Close"
                 },
          		    "intent": {
          		      "name": "Welcome",
          				    "state": resultMatch
          		       }
          	   	  }
              }
          */
};
