var aws = require('aws-sdk');
var ses = new aws.SES({region: 'eu-west-2'});
exports.handler = async (event, context) => {

  var OTP = Math.floor(1000 + Math.random() * 9000);
  const responseObj = {};

  var bodyStr = "Please enter the OTP :"+OTP+" in the chat. This is valid for 5 min."

  await sendMail("OTP verification",bodyStr,OTP,responseObj);

  responseObj.OTPSent = OTP;
 
  return responseObj;
  
   /*var EmailType = event.Details.Parameters.EmailType;
    if(EmailType == 'Payment')
    {
      var paymentReferenceId  = event.Details.Parameters.paymentReferenceId;
      
      var paymentLink = "https://si.delta.com/paymentportal/?paymentReferenceId="+paymentReferenceId;
      
      sendMail("Payment Link for Flight Booking","To complete the payment and the booking, please click on the below payment link:"+paymentLink);
    }
    if(EmailType == 'Booking')
    {
      var paymentReferenceId  = event.Details.Parameters.paymentReferenceId;
       var ToCity  = event.Details.Parameters.ToCity;
        var FromCity  = event.Details.Parameters.FromCity;
         var DepDate  = event.Details.Parameters.DepDate;
      
      
      var bodyStr = "Your flight for dated :"+DepDate+" has been booked. Here is your PNR ID :"+paymentReferenceId+".\nFlight details:\nSoruce City :"+FromCity+"\nDestination City:"+ToCity;
      
      sendMail("Flight Booked",bodyStr);
    }
    else
    {
       sendMail("Flight Ticket is Cancelled","Your flight booking is cancelled. You will recive refund into your payment source within next 7-10 working days.");
    }
  */    
    
};


async function sendMail(subject,body,OTP) {
  const emailParams = {
        Destination: {
          ToAddresses: ["<TO Email>"],
        },
        Message: {
          Body: {
            Text: { Data: body },
          },
          Subject: { Data: subject },
        },
        Source: "<FROM Email>",
  };
      
  try {
        let key = await ses.sendEmail(emailParams).promise();
        console.log("MAIL SENT SUCCESSFULLY!!");      
  } catch (e) {
        console.log("FAILURE IN SENDING MAIL!!", e);
      }  
  return 200;
}