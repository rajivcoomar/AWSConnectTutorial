
var aws = require('aws-sdk');
var db = new aws.DynamoDB({
  region: 'eu-west-2'
});



const queryMyThings = async (event) => {
  var params = {
      TableName: "ProjectPrompts"
  };
  return await db.scan(params).promise();
};





exports.handler = async (event) => {
  console.log(event);
  
    //  var UserLang = event.Details.Parameters.UserLang;

      var dbOutput =  await queryMyThings(event);
      console.log(JSON.stringify(dbOutput));

      let returnObject = {};

      if(dbOutput != {})
      {
        let returnObject = {};

        dbOutput.Items.forEach(item => {
              if (item.Language.S === "English") {
                  returnObject[item.PromptName.S] = item.Prompt_EN.S;
              }
          });

          return returnObject;
      }
      else
      {
        returnObject.isFound = false;

      }

      return returnObject;
  
};
