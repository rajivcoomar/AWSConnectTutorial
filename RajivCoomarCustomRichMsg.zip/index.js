  
  /* MAIN HANDLER */
  exports.handler  = async function(event, context) {
    try {
      console.log(`Request received: ${JSON.stringify(event)}`);
      let response = handleRequest(event);
      console.log(`Returning response: ${JSON.stringify(response)}`);
      return response;
    } catch (err) {
      console.error(`Error processing Lex request:`, err);
      var sessionAttributes = event.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState : "FAILED",
          message: {
            contentType: "PlainText",
            content: "Error in Lex Lambda",
          },
        },
      };
     }
  };
  
  /* PROCESS INBOUND MESSAGE */
  function handleRequest(request) {
  
    let current_intent = request.currentIntent.name;

    let jsonList = {
      "templateType":"ListPicker",                       
      "version":"1.0",                                   
      "data":{                                           
     
         "content":{                                        
            "title":"What produce would you like to buy?", 
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://interactive-msg.s3-us-west-2.amazonaws.com/fruit_34.3kb.jpg",                  
            "imageDescription":"Select a produce to buy",
            "elements":[                                   
               {
                  "title":"Apple",                          
                  "subtitle":"$1.00",
                  "imageType":"URL",
                  "imageData":"https://interactive-message-testing.s3-us-west-2.amazonaws.com/apple_4.2kb.jpg"
               },
               {
                  "title":"Orange",                         
                  "subtitle":"$1.50",
                  "imageType":"URL",                  
                  "imageData":"https://interactive-message-testing.s3-us-west-2.amazonaws.com/orange_17.7kb.jpg",           
               },
                {
                  "title":"Banana",                         
                  "subtitle":"$10.00",
                  "imageType":"URL",                  
                  "imageData":"https://interactive-message-testing.s3-us-west-2.amazonaws.com/banana_7.9kb.jpg",            
                  "imageDescription":"Banana"
               }
               ,
               {
                "title":"Kiwi",                         
                "subtitle":"$10.00",
                "imageType":"URL",                  
                "imageData":"https://interactive-message-testing.s3-us-west-2.amazonaws.com/banana_7.9kb.jpg",            
                "imageDescription":"Banana"
             }
            ]
         }
     }
   };

   let jsonTimePicker = {
    "templateType":"TimePicker",                                 
    "version":"1.0",                                             
    "data":{                                                     
       "replyMessage":{
          "title":"Thanks for selecting",                        
          "subtitle":"Appointment selected",
       },
       "content":{                                               
          "title":"Schedule appointment",                        
          "subtitle":"Tap to select option",
          "timeZoneOffset":-450,
          "location":{
             "latitude":47.616299,                               
             "longitude":-122.4311,                              
             "title":"Oscar" ,                                    
             "radius":1,
          },
          "timeslots":[                                          
                {
                   "date" : "2020-10-31T17:00+00:00" ,            
                   "duration": 60,                               
                },
                {
                   "date" : "2020-11-15T13:00+00:00" ,           
                   "duration": 60,                              
                },
                {
                   "date" : "2020-11-15T16:00+00:00" ,           
                   "duration": 60,                              
                }
             ],           
          }
       }
    };

    let jsonPanel = {
      "templateType":"Panel",                            
      "version":"1.0",                                   
      "data":{                                           
         "replyMessage":{                             
            "title":"Thanks for selecting!",             
            "subtitle":"Option selected",
         },
         "content":{                                      
            "title":"How can I help you?",                
            "subtitle":"Tap to select option",
            "imageType":"URL",                       
            "imageData":"https://interactive-msg.s3-us-west-2.amazonaws.com/company.jpg",                  
            "imageDescription":"Select an option",
            "elements":[                                  
               {
                  "title":"Check self-service options",   
               },
               {
                  "title":"Talk to an agent",                      
               },
               {
                  "title":"End chat",                     
               }
            ]
         }
      }
   } ;

   let jsonQuick = {
    "templateType": "QuickReply",        
    "version": "1.0",                    
    "data": {                            
      "content": {                       
        "title": "Which department would you like?",  
        "elements": [                    
          {
            "title": "Billing"           
          },
          {
            "title": "Cancellation"      
          },
          {
            "title": "New Service"       
          }
        ]
      }
    }
  };

  let jsonCarousel ={
    "templateType": "Carousel",            
    "version": "1.0",                      
    "data": {                              
        "content": {                           
          "title": "View our popular destinations",   
          "elements": [                               
          {
            "templateIdentifier": "template0",        
            "templateType": "Panel",
            "version": "1.0",
            "data": {
              "content": {
                "title": "California",
                "subtitle": "Tap to select option",
                "elements": [
                  {
                    "title": "Book flights"
                  },
                  {
                    "title": "Book hotels"
                  },
                  {
                    "title": "Talk to agent"
                  }
                ]
              }
            }
          },
          {
            "templateIdentifier": "template1",   
            "templateType": "Panel",
            "version": "1.0",
            "data": {
              "content": {
                "title": "New York",
                "subtitle": "Tap to select option",
                "elements": [
                  {
                    "title": "Book flights"
                  },
                  {
                    "title": "Book hotels"
                  },
                  {
                    "title": "Talk to agent"
                  }
                ]
              }
            }
          }
        ]
      }
    }
  };



   if(current_intent === 'MainMenu')
    {
      var sessionAttributes = request.sessionAttributes;
     
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonList),
          },
        },
      };
    }

    else if(current_intent === 'apple')
    {
      var sessionAttributes = request.sessionAttributes;
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonTimePicker),
          },
        },
      };
    }

    else if(current_intent === 'orange')
    {
      var sessionAttributes = request.sessionAttributes;
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonPanel),
          },
        },
      };
    }

    else if(current_intent === 'banana')
    {
      var sessionAttributes = request.sessionAttributes;
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonQuick),
          },
        },
      };
    }

    else if(current_intent === 'kiwi')
    {
      var sessionAttributes = request.sessionAttributes;
    
      return {
        sessionAttributes,
        dialogAction: {
          type: "ElicitIntent",
        
          message: {
            contentType: "CustomPayload",
            content: JSON.stringify(jsonCarousel),
          },
        },
      };
    }

    else { 
      var sessionAttributes = request.sessionAttributes;
      return {
        sessionAttributes,
        dialogAction: {
          type: "Close",
          fulfillmentState :"Fulfilled",
          message: {
            contentType: "PlainText",
            content: "Selected "+current_intent,
          },
        },
      };

    }


    // if(current_intent === 'InteractiveMessageIntent')
    // {
    //   var sessionAttributes = request.sessionAttributes;
    //   var slots = request.currentIntent.slots;
    //   var slotToElicit = SLOTS.ACTION;
    //   return {
    //     sessionAttributes,
    //     dialogAction: {
    //       type: "Close",
    //       fulfillmentState :"Fulfilled",
    //       message: {
    //         contentType: "CustomPayload",
    //         content: JSON.stringify(jsonList),
    //       },
    //     },
    //   };
    // }


    // if(current_intent === 'InteractiveMessageIntent')
    // {
    //   var sessionAttributes = request.sessionAttributes;
    //   var slots = request.currentIntent.slots;
    //   var slotToElicit = SLOTS.ACTION;
    //   return {
    //     sessionAttributes,
    //     dialogAction: {
    //       type: "ElicitSlot",
    //       "intentName" : current_intent,
    //       slots,
    //       slotToElicit,
    //       message: {
    //         contentType: "CustomPayload",
    //         content: JSON.stringify(jsonList),
    //       },
    //     },
    //   };
    // }
  
  
  
  }